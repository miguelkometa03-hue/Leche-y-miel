// ─────────────────────────────────────────────────────────────────────────────
// expo/utils/geminiAgent.ts
//
// Este archivo es el "cerebro" de la integración con Google Gemini.
// Contiene todo lo necesario para que la app hable con la IA:
//   1. Guardar y recuperar la API Key del usuario
//   2. Construir el mensaje que se le envía a Gemini (con contexto de panadería)
//   3. Enviar la petición y devolver la respuesta
//
// ¿Qué es Gemini? Es el modelo de IA de Google. Le enviamos texto (y opcionalmente
// una imagen) y nos responde como lo haría un experto en panadería/pastelería.
// ─────────────────────────────────────────────────────────────────────────────

import AsyncStorage from "@react-native-async-storage/async-storage";
import type { SavedFormula } from "@/types";

// ── Constantes ────────────────────────────────────────────────────────────────

// URL de la API de Google Gemini (modelo Flash = rápido y gratuito)
// Este modelo puede leer TEXTO e IMÁGENES al mismo tiempo (multimodal)
const GEMINI_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent";

// Clave con la que guardamos la API Key en el dispositivo del usuario
// AsyncStorage es como un "cajón" local en el teléfono, nadie más puede verlo
const STORAGE_KEY = "pastrypro_gemini_api_key";

// ── Tipos de datos ────────────────────────────────────────────────────────────

// Representa un mensaje en el historial del chat
export interface ChatMessage {
  id: string;         // identificador único
  role: "user" | "agent";  // quién lo escribió
  text: string;       // el contenido del mensaje
  imageUri?: string;  // (opcional) si el usuario adjuntó una foto
  timestamp: Date;    // cuándo se envió
}

// Tipos de análisis que puede hacer el agente
export type AgentMode =
  | "formula"    // Analizar una fórmula de panadería/pastelería
  | "photo"      // Diagnosticar un producto terminado desde una foto
  | "ideas"      // Generar ideas y variaciones
  | "costs"      // Optimizar costos de ingredientes
  | "general";   // Pregunta libre de panadería

// ── Manejo de la API Key ──────────────────────────────────────────────────────

// Guarda la API Key del usuario en el almacenamiento local del teléfono
// Solo se llama una vez, cuando el usuario la ingresa en Ajustes
export async function saveApiKey(apiKey: string): Promise<void> {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, apiKey.trim());
  } catch (error) {
    console.error("Error guardando la API Key:", error);
    throw new Error("No se pudo guardar la API Key");
  }
}

// Recupera la API Key que el usuario guardó anteriormente
// Devuelve null si el usuario nunca la ha ingresado
export async function getApiKey(): Promise<string | null> {
  try {
    return await AsyncStorage.getItem(STORAGE_KEY);
  } catch {
    return null;
  }
}

// Elimina la API Key guardada (útil si el usuario quiere cambiarla)
export async function clearApiKey(): Promise<void> {
  await AsyncStorage.removeItem(STORAGE_KEY);
}

// ── Construcción del contexto del sistema ─────────────────────────────────────

// Esta función crea el "prompt de sistema" — las instrucciones que le damos
// a Gemini para que sepa cómo debe comportarse y qué información tiene disponible.
// Cuanto más contexto le damos, mejores respuestas nos da.
function buildSystemPrompt(
  mode: AgentMode,
  formula?: SavedFormula
): string {

  // Instrucciones base que siempre se incluyen
  const base = `Eres un experto maestro panadero y pastelero con 20 años de experiencia.
Tu nombre es "Miel", el asistente de la app Pastry-Pro.
Respondes SIEMPRE en español, de forma práctica, clara y amigable.
Usas términos técnicos de panadería pero los explicas cuando son complejos.
Cuando detectas un problema, ofreces soluciones concretas con cantidades o porcentajes.
Nunca inventas información — si no estás seguro, lo dices claramente.`;

  // Si hay una fórmula activa, se la pasamos a Gemini para que la analice
  const formulaContext = formula
    ? `
--- FÓRMULA ACTIVA DEL USUARIO ---
Nombre: ${formula.name}
Área: ${formula.area === "panaderia" ? "Panadería" : "Pastelería"}
Hidratación: ${formula.hydration}%
Piezas: ${formula.pieces} × ${formula.weightPerPiece}g
Ingredientes:
${formula.ingredients
  .map(
    (i) =>
      `  • ${i.name}: ${i.percentage}% (${i.grams.toFixed(1)}g) ${
        i.isFlour ? "[HARINA]" : i.isLiquid ? "[LÍQUIDO]" : ""
      }`
  )
  .join("\n")}
Costo total: ${formula.totalCost.toFixed(2)} por lote
---`
    : "";

  // Instrucciones específicas según el modo de análisis
  const modeInstructions: Record<AgentMode, string> = {
    formula: `Analiza la fórmula del usuario. Evalúa: equilibrio de ingredientes,
      hidratación (si aplica), posibles problemas de textura o sabor,
      y sugiere mejoras específicas con porcentajes.`,

    photo: `El usuario te va a mostrar una foto de su producto terminado.
      Diagnostica visualmente: aspecto de la corteza, color, forma, miga (si se ve),
      y explica qué pudo haber salido mal en el proceso o en la fórmula.`,

    ideas: `Genera ideas creativas de variaciones, sabores nuevos o productos derivados
      basados en la fórmula o ingredientes que mencione el usuario.
      Sé específico con porcentajes cuando sugieras modificaciones.`,

    costs: `Ayuda al usuario a reducir costos. Sugiere ingredientes sustitutos más económicos
      sin comprometer la calidad, con la misma función técnica.
      Indica qué porcentaje del costo original representaría el sustituto.`,

    general: `Responde preguntas generales de panadería y pastelería.
      Si la pregunta es sobre fermentación, horneado, conservación o técnicas,
      da respuestas precisas y aplicables.`,
  };

  return `${base}${formulaContext}\n\nModo actual: ${modeInstructions[mode]}`;
}

// ── Función principal del agente ──────────────────────────────────────────────

// Esta es la función que la pantalla del agente llama cuando el usuario
// hace una pregunta. Devuelve la respuesta de Gemini como texto.
export async function askAgent(params: {
  userMessage: string;       // lo que el usuario escribió o preguntó
  apiKey: string;            // la API Key de Google AI Studio
  mode?: AgentMode;          // tipo de análisis (por defecto: general)
  formula?: SavedFormula;    // fórmula activa para dar contexto a Gemini
  imageBase64?: string;      // foto del producto (en formato base64)
}): Promise<string> {

  const {
    userMessage,
    apiKey,
    mode = "general",
    formula,
    imageBase64,
  } = params;

  // Construimos el mensaje completo que le enviamos a Gemini
  // "parts" son las partes del mensaje — puede ser texto, imagen, o ambos
  const parts: object[] = [];

  // Si hay imagen, la ponemos PRIMERO (Gemini la analiza mejor así)
  if (imageBase64) {
    parts.push({
      inlineData: {
        mimeType: "image/jpeg",
        data: imageBase64,
      },
    });
  }

  // Luego va el contexto del sistema + el mensaje del usuario
  parts.push({
    text: buildSystemPrompt(mode, formula) + "\n\nUsuario: " + userMessage,
  });

  // Armamos el cuerpo de la petición que le enviamos a Google
  const requestBody = {
    contents: [{ parts }],
    generationConfig: {
      temperature: 0.7,      // 0 = muy preciso, 1 = muy creativo. 0.7 es un buen balance
      maxOutputTokens: 1024, // máximo de palabras en la respuesta (~750 palabras)
      topP: 0.9,
    },
    safetySettings: [
      // Desactivamos filtros de seguridad para contenido de alimentos
      // (a veces bloquean términos como "fermentación" o "alcohol" en recetas)
      {
        category: "HARM_CATEGORY_DANGEROUS_CONTENT",
        threshold: "BLOCK_ONLY_HIGH",
      },
    ],
  };

  // Enviamos la petición a Google Gemini
  const response = await fetch(`${GEMINI_URL}?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(requestBody),
  });

  // Si Google nos devuelve un error, lo capturamos y mostramos un mensaje claro
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const status = response.status;

    // Errores comunes y sus soluciones
    if (status === 400) {
      throw new Error("API Key inválida. Verifica que la copiaste correctamente en Ajustes.");
    }
    if (status === 429) {
      throw new Error("Límite de consultas alcanzado. Espera un minuto e intenta de nuevo.");
    }
    if (status === 403) {
      throw new Error("La API Key no tiene permisos para Gemini. Verifica en Google AI Studio.");
    }

    const msg = (errorData as { error?: { message?: string } })?.error?.message ?? "Error desconocido";
    throw new Error(`Error de Google Gemini: ${msg}`);
  }

  // Procesamos la respuesta que nos devuelve Google
  const data = await response.json() as {
    candidates?: Array<{
      content?: { parts?: Array<{ text?: string }> };
      finishReason?: string;
    }>;
    promptFeedback?: { blockReason?: string };
  };

  // Si la respuesta fue bloqueada por filtros de seguridad
  if (data.promptFeedback?.blockReason) {
    throw new Error("La consulta fue bloqueada por los filtros de seguridad de Google.");
  }

  // Extraemos el texto de la respuesta
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text;

  if (!text) {
    throw new Error("Gemini no devolvió una respuesta. Intenta reformular tu pregunta.");
  }

  return text.trim();
}

// ── Sugerencias de preguntas por modo ─────────────────────────────────────────

// Estas sugerencias aparecen en la pantalla del agente para ayudar
// al usuario a saber qué puede preguntar
export const AGENT_SUGGESTIONS: Record<AgentMode, string[]> = {
  formula: [
    "¿Está equilibrada mi fórmula?",
    "¿Por qué me queda gomoso el pan?",
    "¿Cómo mejorar la hidratación?",
    "¿Puedo agregar más grasa sin afectar la textura?",
  ],
  photo: [
    "¿Por qué no subió bien?",
    "¿Qué falló en la corteza?",
    "¿La fermentación fue correcta?",
    "¿Cómo se ve la miga?",
  ],
  ideas: [
    "Dame 3 variaciones con chocolate",
    "¿Qué especias combinan con esta fórmula?",
    "¿Cómo hacer una versión sin gluten?",
    "Sugiere un relleno complementario",
  ],
  costs: [
    "¿Cómo reduzco el costo sin bajar calidad?",
    "¿Qué puedo sustituir por algo más barato?",
    "¿Cuál ingrediente es el más caro relativamente?",
    "Alternativas a la mantequilla",
  ],
  general: [
    "¿Cuánto tiempo fermentar a temperatura ambiente?",
    "¿Qué temperatura interna debe tener el pan?",
    "¿Cómo sé si mi masa madre está activa?",
    "Diferencia entre levadura fresca y seca",
  ],
};
